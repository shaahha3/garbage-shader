override leaf_opacity: f32 = 0.9;
override shadow_strength: f32 = 0.58;
override water_strength: f32 = 0.8;
override sunlight_strength: f32 = 0.3;

fn material(input: MaterialInput) -> Surface {
    let normal = normalize(input.normal);
    let base = input.albedo * input.tint * vec4<f32>(input.lightmap, 1.0);
    var color = base.rgb;
    var visibility = 1.0;

    if frame.has_shadow != 0u {
        let shadow_coord = shadow_position(input.position + normal * (frame.shadow_center_texel * 1.5));
        if shadow_coord.x >= 0.0 && shadow_coord.x <= 1.0
            && shadow_coord.y >= 0.0 && shadow_coord.y <= 1.0 {
            visibility = textureSampleCompareLevel(
                shadow_map,
                shadow_sampler,
                shadow_coord.xy,
                shadow_coord.z
            );
        }
    }

    let daylight = smoothstep(-0.12, 0.18, frame.sun_direction.y);
    let sun_angle = max(dot(normal, frame.sun_direction), 0.0);
    let direct_light = sun_angle * daylight * visibility;
    color += input.albedo.rgb * input.tint.rgb
        * vec3<f32>(1.0, 0.92, 0.78)
        * direct_light * sunlight_strength;
    color *= 1.0 - sun_angle * (1.0 - visibility) * shadow_strength;

    if input.material == 1u || input.material == 2u {
        let backlight = pow(max(dot(-normal, frame.sun_direction), 0.0), 2.0)
            * daylight * visibility;
        color += input.albedo.rgb * vec3<f32>(0.12, 0.2, 0.06) * backlight * 0.18;
    }

    var alpha = base.a;
    if input.material == 1u {
        alpha *= leaf_opacity;
    }

    if input.fluid == 1u {
        let view_delta = -input.position;
        let view_direction = view_delta / max(length(view_delta), 0.0001);
        let phase_a = input.position.x * 1.7 + input.position.z * 1.2 + frame.time * 1.1;
        let phase_b = input.position.z * 2.1 - input.position.x * 1.4 - frame.time * 0.85;
        let wave_a = sin(phase_a);
        let wave_b = cos(phase_b);
        let wave_normal = normalize(normal + vec3<f32>(
            0.075 * (1.7 * cos(phase_a) + 1.4 * sin(phase_b)),
            0.0,
            0.075 * (1.2 * cos(phase_a) - 2.1 * sin(phase_b))
        ));
        let fresnel = pow(1.0 - max(dot(wave_normal, view_direction), 0.0), 4.0);
        let ripple = (wave_a + wave_b) * 0.5;

        var reflected = vec3<f32>(0.42, 0.62, 0.76);
        if frame.has_reflection != 0u {
            reflected = textureSample(reflection, reflection_sampler, input.screen).rgb;
        }

        let half_vector = normalize(frame.sun_direction + view_direction);
        let sun_glint = pow(max(dot(wave_normal, half_vector), 0.0), 48.0)
            * daylight * visibility;
        let water = input.albedo.rgb * (0.78 + ripple * 0.055)
            + reflected * (0.16 + fresnel * 0.42)
            + vec3<f32>(1.0, 0.88, 0.66) * sun_glint * 0.45;
        color = mix(color, water, water_strength);
    }

    let distance = length(input.position);
    let extra_haze = smoothstep(frame.fog_start, frame.fog_end, distance)
        * (0.16 + frame.rain * 0.18);
    color = mix(color, frame.fog_color, extra_haze);

    return Surface(vec4<f32>(color, alpha));
}
