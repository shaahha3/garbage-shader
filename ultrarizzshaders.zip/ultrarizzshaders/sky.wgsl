override sky_glow: f32 = 1.0;

fn segment_distance(point: vec2<f32>, start: vec2<f32>, end: vec2<f32>) -> f32 {
    let segment = end - start;
    let length_squared = dot(segment, segment);
    let along = clamp(dot(point - start, segment) / max(length_squared, 0.000001), 0.0, 1.0);
    return length(point - (start + segment * along));
}

fn bird_shape(point: vec2<f32>, flap: f32, size: f32) -> f32 {
    let wing_tip = 0.035 * size;
    let wing_y = (-0.002 + flap * 0.014) * size;
    let left_wing = segment_distance(point, vec2<f32>(0.0, 0.0), vec2<f32>(-wing_tip, wing_y));
    let right_wing = segment_distance(point, vec2<f32>(0.0, 0.0), vec2<f32>(wing_tip, wing_y));
    let body = segment_distance(point, vec2<f32>(-0.008 * size, 0.0), vec2<f32>(0.01 * size, 0.0));
    return 1.0 - smoothstep(0.0015 * size, 0.003 * size, min(min(left_wing, right_wing), body));
}

fn hash_cell(cell: vec2<f32>) -> f32 {
    return fract(sin(dot(cell, vec2<f32>(127.1, 311.7))) * 43758.5453);
}

fn sky(input: SkyInput) -> vec4<f32> {
    let ray = normalize(input.direction);
    let sun = normalize(frame.sun_direction);
    let sun_height = frame.sun_direction.y;
    let day = smoothstep(-0.12, 0.22, sun_height) * (1.0 - frame.rain * 0.7);
    let twilight = (1.0 - smoothstep(0.0, 0.32, abs(sun_height)))
        * (1.0 - frame.rain * 0.6);
    let horizon = pow(1.0 - abs(ray.y), 3.0);
    let zenith = pow(max(ray.y, 0.0), 0.65);
    let toward_sun = max(dot(ray, sun), 0.0);

    let blue_scatter = vec3<f32>(0.2, 0.42, 0.9) * zenith * day * 0.18;
    let warm_horizon = vec3<f32>(1.0, 0.34, 0.12) * horizon * twilight * 0.2;
    let low_sun = 1.0 - smoothstep(0.02, 0.4, sun_height);
    let broad_halo = pow(toward_sun, 5.0) * 0.28;
    let tight_halo = pow(toward_sun, 24.0) * 0.52;
    let solar_glow = vec3<f32>(1.0, 0.62, 0.32)
        * (broad_halo + tight_halo * low_sun)
        * day * sky_glow;

    let haze = horizon * (0.08 + frame.rain * 0.18);
    var color = mix(input.color.rgb + blue_scatter, frame.fog_color, haze)
        + warm_horizon + solar_glow;

    let bird_visibility = smoothstep(0.02, 0.16, ray.y);
    for (var i = 0; i < 3; i += 1) {
        let index = f32(i);
        let progress = fract(frame.time * (0.035 + index * 0.006) + index * 0.37);
        let bird_x = progress * 1.8 - 0.9;
        let bird_y = 0.24 + index * 0.12 + sin(frame.time * 0.7 + index * 2.1) * 0.025;
        let local = (ray.xy - vec2<f32>(bird_x, bird_y)) / 0.8;
        let flap = sin(frame.time * 7.0 + index * 2.7);
        let silhouette = bird_shape(local, flap, 0.65 + index * 0.12) * bird_visibility;
        color = mix(color, vec3<f32>(0.045, 0.055, 0.075), silhouette * 0.9);
    }

    let particle_space = ray.xy * vec2<f32>(90.0, 70.0)
        + vec2<f32>(frame.time * 0.35, frame.time * 0.12);
    let cell = floor(particle_space);
    let local_particle = fract(particle_space) - vec2<f32>(0.5, 0.5);
    let seed = hash_cell(cell);
    let particle_radius = 0.045 + seed * 0.035;
    let particle = (1.0 - smoothstep(particle_radius, particle_radius + 0.035, length(local_particle)))
        * step(0.94, seed);
    let night = 1.0 - day;
    let twinkle = 0.45 + 0.55 * sin(frame.time * 2.4 + seed * 6.28318);
    color += vec3<f32>(0.72, 0.82, 1.0) * particle * twinkle * (0.12 + night * 0.24);

    return vec4<f32>(color, input.color.a);
}
