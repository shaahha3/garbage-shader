override foliage_sway: f32 = 1.0;

fn vertex(input: VertexInput) -> vec3<f32> {
    if input.material != 1u && input.material != 2u {
        return input.position;
    }

    let world_position = input.position + frame.camera_position;
    let phase = frame.time * 1.35 + world_position.x * 1.7 + world_position.z * 1.9;
    let tip_weight = smoothstep(0.05, 0.95, input.uv.y);
    let strength = select(1.0, 0.65, input.material == 1u);
    let sway = vec3<f32>(
        sin(phase) * 0.035,
        0.0,
        cos(phase * 0.71) * 0.024
    );
    return input.position + sway * tip_weight * strength * foliage_sway;
}
