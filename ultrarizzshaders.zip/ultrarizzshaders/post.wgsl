override solar_bloom: f32 = 0.35;

fn bright_sample(uv: vec2<f32>) -> vec3<f32> {
    let color = textureSampleLevel(previous, linear_sampler, uv, 0.0).rgb;
    let brightness = dot(color, vec3<f32>(0.2126, 0.7152, 0.0722));
    let sky_scale = select(1.0, 0.35, depth_at(uv) == 0.0);
    return color * smoothstep(0.78, 1.0, brightness) * sky_scale;
}

fn post(input: PostInput) -> vec4<f32> {
    if solar_bloom <= 0.0 {
        return input.color;
    }

    let pixel_step = 1.0 / frame.resolution;
    var bloom = vec3<f32>(0.0);
    for (var i = 0; i < 12; i += 1) {
        let angle = f32(i) * 0.5235988;
        let radius = select(3.0, 7.0, i % 2 == 1);
        let offset = vec2<f32>(cos(angle), sin(angle)) * radius * pixel_step;
        bloom += bright_sample(input.uv + offset);
    }

    return vec4<f32>(input.color.rgb + bloom * (solar_bloom / 10.0), input.color.a);
}
